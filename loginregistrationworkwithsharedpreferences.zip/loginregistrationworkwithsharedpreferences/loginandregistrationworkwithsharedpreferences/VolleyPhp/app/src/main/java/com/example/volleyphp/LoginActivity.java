package com.example.volleyphp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    EditText email,password;
    Button btnadd;

    String url="https://webtech2030.000webhostapp.com/login.php";





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);

        btnadd = findViewById(R.id.btnadd);



        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String myemail = email.getText().toString();
                String mypassword = password.getText().toString();


                ProgressDialog progressDialog = new ProgressDialog(LoginActivity.this);
                progressDialog.setTitle("Please Wait");
                progressDialog.setMessage("Please Wait login process start..");
                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                progressDialog.show();




                StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        if (response.equalsIgnoreCase("ok")){


                            SharedPreferences sharedPreferences = getSharedPreferences("myref",MODE_PRIVATE);
                            SharedPreferences.Editor myEdit = sharedPreferences.edit();
                            myEdit.putString("email", myemail);
                            myEdit.commit();



                            Intent intent = new Intent(LoginActivity.this,Dashboard.class);
                            startActivity(intent);
                            finish();

                        }else{

                            Toast.makeText(LoginActivity.this, "Invalid email or password", Toast.LENGTH_SHORT).show();
                        }




                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                       progressDialog.dismiss();
                    }
                }){


                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {

                        Map<String,String> parms = new HashMap<>();
                        parms.put("userEmail",myemail);
                        parms.put("userPassword",mypassword);



                        return parms;
                    }
                };


                RequestQueue requestQueue = Volley.newRequestQueue(LoginActivity.this);
                requestQueue.add(request);
















            }
        });




    }
}