package com.example.volleyphp;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Dashboard extends AppCompatActivity {

    TextView email;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        email = findViewById(R.id.email);
        SharedPreferences sh = getSharedPreferences("myref",MODE_PRIVATE);
        String s1 = sh.getString("email", "");
        email.setText(s1);

    }
}